# ICONIC GAME: copia preparada para tele y micrófonos móviles

Esta carpeta es una copia de trabajo. Los archivos originales de `APP GAME ICONIC GAME` no se han modificado.

## Publicar gratis en GitHub Pages

El micrófono de los móviles necesita que la página se abra por HTTPS. El servidor local de `JUGAR.command` sirve por HTTP a los teléfonos de la red local, por lo que no sirve para esta modalidad.

GitHub Pages ofrece una dirección HTTPS gratuita. Para usarlo en el plan gratuito, el repositorio debe ser público: cualquier persona podrá ver tanto la página como el código y los recursos del juego.

1. Sube el contenido de esta carpeta a un repositorio público de GitHub.
2. En el repositorio, abre **Settings → Pages** y selecciona publicar desde la rama `main`, carpeta `/ (root)`.
3. Espera a que Pages indique la dirección `https://…github.io/…`.
4. Abre esa dirección en el navegador de la tele.
5. En el menú del juego, abre **Móviles como mandos** y escanea el QR con cada teléfono.
6. Al pulsar **ENTRAR**, permite el micrófono en cada teléfono. La voz se reconoce desde el navegador móvil y el texto se envía a la partida.

No se necesita servidor propio ni una clave de API. El reconocimiento usa la capacidad de voz del navegador del teléfono y, según el navegador, puede requerir Internet y procesar audio mediante el servicio de reconocimiento del proveedor.

## Navegadores y límites

El mando intenta usar `SpeechRecognition` / `webkitSpeechRecognition` en español. Esta interfaz no está disponible en todos los navegadores ni funciona igual en todos los móviles. Si el teléfono no la ofrece o deniega el micrófono, los botones **¡CORRECTO!**, **PASAR** y las opciones táctiles siguen disponibles. La partida y los controles necesitan Internet; en algunas redes la conexión directa entre móviles y tele puede fallar.

El archivo `.nojekyll` evita que GitHub Pages omita la carpeta `_tts`, que contiene audios usados por el juego. Al publicarla, cualquier persona podrá abrir el juego; el código de sala de seis letras reduce colisiones, pero no equivale a una contraseña.
